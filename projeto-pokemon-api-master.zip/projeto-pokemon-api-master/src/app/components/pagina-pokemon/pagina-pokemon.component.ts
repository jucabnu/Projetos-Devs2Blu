import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pagina-pokemon',
  templateUrl: './pagina-pokemon.component.html',
  styleUrls: ['./pagina-pokemon.component.scss']
})
export class PaginaPokemonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
