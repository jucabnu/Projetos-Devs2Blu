import { PokemonList } from './pokemon-list';

describe('PokemonList', () => {
  it('should create an instance', () => {
    expect(new PokemonList()).toBeTruthy();
  });
});
