export class ResponseLink {
  name?: string;
  url?: string;

  constructor(Object: Partial<ResponseLink>){
    
  }

}
