import { Sprites } from './sprites';

describe('Sprites', () => {
  it('should create an instance', () => {
    expect(new Sprites()).toBeTruthy();
  });
});
